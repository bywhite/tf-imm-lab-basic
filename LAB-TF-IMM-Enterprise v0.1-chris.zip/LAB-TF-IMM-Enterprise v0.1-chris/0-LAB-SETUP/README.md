

Initial Workstation Setup:
  https://blog.gruntwork.io/an-introduction-to-terraform-f17df9c6d180


Types of Variables:
  https://spacelift.io/blog/how-to-use-terraform-variables
  
Locals: 
  https://spacelift.io/blog/terraform-locals




